<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Department</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4361ee;
            --secondary: #3f37c9;
            --accent: #4895ef;
            --light: #f8f9ff;
            --dark: #212529;
        }
        
        body {
            background: linear-gradient(135deg, #f5f7ff 0%, #e8ecff 100%);
            font-family: 'Poppins', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
        }
        
        .form-container {
            background: white;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(67, 97, 238, 0.15);
            padding: 40px;
            width: 100%;
            max-width: 500px;
            margin: 20px auto;
            border: 1px solid rgba(255,255,255,0.3);
        }
        
        .form-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .form-header h2 {
            color: var(--primary);
            font-weight: 600;
            margin-bottom: 10px;
        }
        
        .form-header p {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-control {
            height: 50px;
            border-radius: 8px;
            border: 1px solid #e0e4ff;
            padding: 0 15px;
            font-size: 0.95rem;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.2);
        }
        
        textarea.form-control {
            height: auto;
            padding: 15px;
            resize: vertical;
        }
        
        label {
            font-weight: 500;
            color: var(--dark);
            margin-bottom: 8px;
            display: block;
            font-size: 0.9rem;
        }
        
        .btn-submit {
            background: linear-gradient(to right, var(--primary), var(--secondary));
            border: none;
            color: white;
            padding: 12px 25px;
            font-size: 1rem;
            font-weight: 500;
            border-radius: 8px;
            width: 100%;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 4px 15px rgba(67, 97, 238, 0.3);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(67, 97, 238, 0.4);
        }
        
        .form-footer {
            text-align: center;
            margin-top: 20px;
            font-size: 0.85rem;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <div class="form-header">
                <h2>Create New Department</h2>
                <p>Fill in the details to add a new department</p>
            </div>
            
            <form action="" method="post">
                <div class="form-group">
                    <label for="name">Department Name</label>
                    <input type="text" class="form-control" name="Name" required>
                </div>
                
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea class="form-control" name="description" rows="3"></textarea>
                </div>
                
                <button type="submit" class="btn-submit">Create Department</button>
                
                <div class="form-footer">
                    <p>Need help? <a href="#">Contact support</a></p>
                </div>
            </form>
        </div>
    </div>
</body>
</html>