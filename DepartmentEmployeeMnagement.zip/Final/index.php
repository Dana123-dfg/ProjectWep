<?php
    include 'connection.php';

    $sql = "SELECT employees.*, department.name AS department_name
            FROM employees
            INNER JOIN department ON department.id = employees.Department_id";

    $result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Management</title>
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="/styles.css">
    
</head>
<body>
    <div class="container-fluid main-container">
        <div class="header-section mb-4">
            <h1 class="text-center display-4">Employee Management System</h1>
            <div class="action-buttons">
                <a href="insertEmp.php" class="btn btn-primary">
                    <i class="fas fa-user-plus"></i> Add Employee
                </a>
                <a href="add_department.php" class="btn btn-info">
                    <i class="fas fa-building"></i> Add Department
                </a>
                <a href="D_Emp.php" class="btn btn-secondary">
                    <i class="fas fa-eye"></i> View Departments
                </a>
            </div>
        </div>
        
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h3 class="card-title mb-0">Employee Directory</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead class="thead-light">
                            <tr>
                                <th><i class="fas fa-building"></i> Department</th>
                                <th><i class="fas fa-user"></i> Employee</th>
                                <th><i class="fas fa-id-badge"></i> Profile</th>
                                <th><i class="fas fa-phone"></i> Phone</th>
                                <th><i class="fas fa-cog"></i> Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                    echo "<tr>";
                                    echo "<td>" . htmlspecialchars($row["department_name"]) . "</td>";
                                    echo "<td>" . htmlspecialchars($row["Emp_name"]) . "</td>";
                                    echo "<td>" . htmlspecialchars($row["profile"]) . "</td>";
                                    echo "<td>" . htmlspecialchars($row["phone"]) . "</td>";
                                    echo "<td class='action-buttons'>";
                                        echo "<a href='editEmp.php?id=" . $row["Emp_id"] . "' class='btn btn-sm btn-warning'><i class='fas fa-edit'></i> Edit</a> ";
                                        echo "<a href='deleteEmp.php?id=" . $row["Emp_id"] . "' class='btn btn-sm btn-danger' onclick='return confirmDelete()'><i class='fas fa-trash-alt'></i> Delete</a>";
                                    echo "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='5' class='text-center text-muted'>No employees found</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>

    <script>
        function confirmDelete() {
            return confirm("Are you sure you want to delete this employee?");
        }
    </script>
</body>
</html>

<?php
$conn->close();
?>